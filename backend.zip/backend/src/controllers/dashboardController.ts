import { Response } from "express";
import Task from "../models/Task";
import { AuthRequest } from "../middleware/authMiddleware";

export const getTodayDashboard = async (
  req: AuthRequest,
  res: Response
) => {
  try {
    // Today's date (00:00:00)
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Tomorrow's date (00:00:00)
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);

    const tasks = await Task.find({
      userId: req.userId,
      plannedDate: {
        $gte: today,
        $lt: tomorrow,
      },
    })
      .select(
        "_id title description priority points completed completedAt plannedDate"
      )
      .sort({
        createdAt: 1,
      });

    let plannedTasks = 0;
    let completedTasks = 0;

    let plannedPoints = 0;
    let earnedPoints = 0;

    const todayTasks = [];
    const completedToday = [];
    const pendingToday = [];

    for (const task of tasks) {
      plannedTasks++;
      plannedPoints += task.points;

      const taskData = {
        id: task._id,
        title: task.title,
        description: task.description,
        priority: task.priority,
        points: task.points,
        completed: task.completed,
        completedAt: task.completedAt,
      };

      todayTasks.push(taskData);

      if (task.completed) {
        completedTasks++;
        earnedPoints += task.points;
        completedToday.push(taskData);
      } else {
        pendingToday.push(taskData);
      }
    }

    const remainingTasks = plannedTasks - completedTasks;
    const remainingPoints = plannedPoints - earnedPoints;

    const completionRate =
      plannedPoints === 0
        ? 0
        : Math.round((earnedPoints / plannedPoints) * 100);

    return res.status(200).json({
      success: true,

      summary: {
        plannedTasks,
        completedTasks,
        remainingTasks,

        plannedPoints,
        earnedPoints,
        remainingPoints,

        completionRate,
      },

      todayTasks,

      completedToday,

      pendingToday,
    });
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

export const getMonthlyDashboard = async (
  req: AuthRequest,
  res: Response
) => {
  try {
    const now = new Date();

    const startOfMonth = new Date(
      now.getFullYear(),
      now.getMonth(),
      1
    );

    const endOfMonth = new Date(
      now.getFullYear(),
      now.getMonth() + 1,
      1
    );

    const tasks = await Task.find({
      userId: req.userId,
      plannedDate: {
        $gte: startOfMonth,
        $lt: endOfMonth,
      },
    });

    const daysInMonth = new Date(
      now.getFullYear(),
      now.getMonth() + 1,
      0
    ).getDate();

    const dayWiseData = new Map<
      number,
      {
        plannedPoints: number;
        earnedPoints: number;
      }
    >();

    for (const task of tasks) {
      const day = task.plannedDate.getDate();

      if (!dayWiseData.has(day)) {
        dayWiseData.set(day, {
          plannedPoints: 0,
          earnedPoints: 0,
        });
      }

      const data = dayWiseData.get(day)!;

      data.plannedPoints += task.points;

      if (task.completed) {
        data.earnedPoints += task.points;
      }
    }

    const monthly = [];

    for (let day = 1; day <= daysInMonth; day++) {
      const data = dayWiseData.get(day);

      const plannedPoints = data?.plannedPoints ?? 0;
      const earnedPoints = data?.earnedPoints ?? 0;

      const completionPercentage =
        plannedPoints === 0
          ? 0
          : Math.round(
              (earnedPoints / plannedPoints) * 100
            );

      monthly.push({
        day,
        plannedPoints,
        earnedPoints,
        completionPercentage,
      });
    }

    return res.json({
      success: true,
      monthly,
    });
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

export const getWeeklyDashboard = async (
  req: AuthRequest,
  res: Response
) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Last 7 days (including today)
    const startDate = new Date(today);
    startDate.setDate(today.getDate() - 6);

    const endDate = new Date(today);
    endDate.setDate(today.getDate() + 1);

    const tasks = await Task.find({
      userId: req.userId,
      plannedDate: {
        $gte: startDate,
        $lt: endDate,
      },
    });

    const weekMap = new Map<
      string,
      {
        plannedPoints: number;
        earnedPoints: number;
      }
    >();

    for (const task of tasks) {
      const key = task.plannedDate.toISOString().split("T")[0];

      if (!weekMap.has(key)) {
        weekMap.set(key, {
          plannedPoints: 0,
          earnedPoints: 0,
        });
      }

      const data = weekMap.get(key)!;

      data.plannedPoints += task.points;

      if (task.completed) {
        data.earnedPoints += task.points;
      }
    }

    const weekly = [];

    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(today.getDate() - i);

      const key = date.toISOString().split("T")[0];

      const data = weekMap.get(key);

      const plannedPoints = data?.plannedPoints ?? 0;
      const earnedPoints = data?.earnedPoints ?? 0;

      const completionPercentage =
        plannedPoints === 0
          ? 0
          : Math.round((earnedPoints / plannedPoints) * 100);

      weekly.push({
        day: date.toLocaleDateString("en-US", {
          weekday: "short",
        }),
        plannedPoints,
        earnedPoints,
        completionPercentage,
      });
    }

    return res.json({
      success: true,
      weekly,
    });

  } catch (error) {

    console.error(error);

    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });

  }
};

export const getStreakDashboard = async (
  req: AuthRequest,
  res: Response
) => {
  try {
    const STREAK_THRESHOLD = 50;
    const MAX_GRACE_DAYS = 3;

    const tasks = await Task.find({
      userId: req.userId,
    }).sort({
      plannedDate: 1,
    });

    const dayMap = new Map<
      string,
      {
        plannedPoints: number;
        earnedPoints: number;
      }
    >();

    // Group tasks by day
    for (const task of tasks) {
      const key = task.plannedDate.toISOString().split("T")[0];

      if (!dayMap.has(key)) {
        dayMap.set(key, {
          plannedPoints: 0,
          earnedPoints: 0,
        });
      }

      const data = dayMap.get(key)!;

      data.plannedPoints += task.points;

      if (task.completed) {
        data.earnedPoints += task.points;
      }
    }

    const dates = [...dayMap.keys()].sort();

    let currentStreak = 0;
    let longestStreak = 0;

    // ---------- Longest Streak ----------
    let running = 0;
    let grace = 0;

    for (const date of dates) {
      const day = dayMap.get(date)!;

      if (day.plannedPoints === 0) {
        grace++;

        if (grace > MAX_GRACE_DAYS) {
          running = 0;
          grace = 0;
        }

        continue;
      }

      const percentage =
        (day.earnedPoints / day.plannedPoints) * 100;

      if (percentage >= STREAK_THRESHOLD) {
        running++;
        longestStreak = Math.max(longestStreak, running);
      } else {
        running = 0;
        grace = 0;
      }
    }

    // ---------- Current Streak ----------
    running = 0;
    grace = 0;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    for (let i = 0; ; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() - i);

      const key = date.toISOString().split("T")[0];

      const day = dayMap.get(key);

      // No tasks that day
      if (!day) {
        grace++;

        if (grace > MAX_GRACE_DAYS) {
          break;
        }

        continue;
      }

      if (day.plannedPoints === 0) {
        grace++;

        if (grace > MAX_GRACE_DAYS) {
          break;
        }

        continue;
      }

      const percentage =
        (day.earnedPoints / day.plannedPoints) * 100;

      if (percentage >= STREAK_THRESHOLD) {
        running++;
      } else {
        break;
      }
    }

    currentStreak = running;

    return res.json({
      success: true,
      streak: {
        currentStreak,
        longestStreak,
        threshold: STREAK_THRESHOLD,
        graceDays: MAX_GRACE_DAYS,
      },
    });

  } catch (error) {

    console.error(error);

    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });

  }
};